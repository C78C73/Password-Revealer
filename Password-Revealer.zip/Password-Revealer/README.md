# Password-Revealer
This is chrome extension that reveals the users login password for them to see for websites that dont allow for that functionaltity.
